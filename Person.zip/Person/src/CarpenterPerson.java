// Author: Zachary Carpenter
// Date: 08/24/2021
// Purpose: Displays info to the console about me!

public class CarpenterPerson {

	public static void main(String[] args) {
		String name = "Zac Carpenter";
		String hometown = "Durham, NC";
		String phoneNumber = "910-999-9999";
		String major = "Computer Science with a concentration in Software Development";
		String dreamJob = "Video Game Developer";

		System.out.println("My name is " + name);
		System.out.println("I currently live in " + hometown);
		System.out.println("My phone number is " + phoneNumber);
		System.out.println("My major is " + major);
		System.out.println("My dream job is to work as a " + dreamJob);
	}

}
