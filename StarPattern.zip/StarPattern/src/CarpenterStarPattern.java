// Author: Zachary Carpenter
// Date: 08/30/2021
// Purpose: Creating a program to display a star pattern

public class CarpenterStarPattern {

	public static void main(String[] args) {
		
		System.out.println("   *   ");
		System.out.println("  ***  ");
		System.out.println(" ***** ");
		System.out.println("*******");
		System.out.println(" ***** ");
		System.out.println("  ***  ");
		System.out.println("   *   ");

	}

}
